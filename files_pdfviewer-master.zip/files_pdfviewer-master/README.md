files_pdfviewer
======

This application integrates the [PDF.js](https://mozilla.github.io/pdf.js/) library into Nextcloud. Using this application users can view their PDF files online without downloading the file.

[![Scrutinizer Code Quality](https://scrutinizer-ci.com/g/owncloud/files_pdfviewer/badges/quality-score.png?b=master)](https://scrutinizer-ci.com/g/nextcloud/files_pdfviewer/?branch=master)
[![Code Coverage](https://scrutinizer-ci.com/g/owncloud/files_pdfviewer/badges/coverage.png?b=master)](https://scrutinizer-ci.com/g/nextcloud/files_pdfviewer/?branch=master)
[![Build Status](https://travis-ci.org/owncloud/files_pdfviewer.svg)](https://travis-ci.org/nextcloud/files_pdfviewer)

Maintainers
===========
- [Lukas Reschke](https://github.com/LukasReschke)
